
public class Rectangle extends Shape {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rectangle r= new Rectangle();
		r.clacArea();
		
		
	}
	
	public void clacArea() {
		System.out.println("Rectangle: calcArea()");
		System.out.println("�簢���� ����: "+ d1*d2);
	} 

}
